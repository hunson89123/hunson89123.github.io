declare namespace _default {
    let IDLE: number;
    let LOADING: number;
    let LOADED: number;
    let ERROR: number;
    let EMPTY: number;
}
export default _default;
//# sourceMappingURL=ImageState.d.ts.map